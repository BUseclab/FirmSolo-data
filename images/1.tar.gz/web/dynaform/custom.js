var str_wps_name_long = "Wi-Fi Protected Setup";
var str_wps_name_short = "WPS";
var wlan_wds = 1;

var display_pin_settings = 0;//visable or not.added by tf,101224.

var our_web_site = "www.tp-link.com"
var wireless_ssid_prefix = "TP-LINK"
